﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button13 = new Button();
            textBox2 = new TextBox();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.LightGray;
            textBox1.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox1.ForeColor = Color.Black;
            textBox1.Location = new Point(3, 53);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(318, 71);
            textBox1.TabIndex = 0;
            textBox1.Text = "0";
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // button1
            // 
            button1.BackColor = Color.White;
            button1.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(27, 198);
            button1.Name = "button1";
            button1.Size = new Size(58, 60);
            button1.TabIndex = 1;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = false;
            button1.Click += bnt;
            // 
            // button2
            // 
            button2.BackColor = Color.White;
            button2.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = SystemColors.ActiveCaptionText;
            button2.Location = new Point(96, 198);
            button2.Name = "button2";
            button2.Size = new Size(58, 60);
            button2.TabIndex = 2;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = false;
            button2.Click += bnt;
            // 
            // button3
            // 
            button3.BackColor = Color.White;
            button3.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = SystemColors.ActiveCaptionText;
            button3.Location = new Point(165, 198);
            button3.Name = "button3";
            button3.Size = new Size(58, 60);
            button3.TabIndex = 3;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = false;
            button3.Click += bnt;
            // 
            // button4
            // 
            button4.BackColor = Color.White;
            button4.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = SystemColors.ActiveCaptionText;
            button4.Location = new Point(165, 262);
            button4.Name = "button4";
            button4.Size = new Size(58, 60);
            button4.TabIndex = 4;
            button4.Text = "6";
            button4.UseVisualStyleBackColor = false;
            button4.Click += bnt;
            // 
            // button5
            // 
            button5.BackColor = Color.White;
            button5.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = SystemColors.ActiveCaptionText;
            button5.Location = new Point(96, 262);
            button5.Name = "button5";
            button5.Size = new Size(58, 60);
            button5.TabIndex = 5;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = false;
            button5.Click += bnt;
            // 
            // button6
            // 
            button6.BackColor = Color.White;
            button6.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.ForeColor = SystemColors.ActiveCaptionText;
            button6.Location = new Point(27, 262);
            button6.Name = "button6";
            button6.Size = new Size(58, 60);
            button6.TabIndex = 6;
            button6.Text = "4";
            button6.UseVisualStyleBackColor = false;
            button6.Click += bnt;
            // 
            // button7
            // 
            button7.BackColor = Color.White;
            button7.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button7.ForeColor = SystemColors.ActiveCaptionText;
            button7.Location = new Point(165, 326);
            button7.Name = "button7";
            button7.Size = new Size(58, 60);
            button7.TabIndex = 7;
            button7.Text = "9";
            button7.UseVisualStyleBackColor = false;
            button7.Click += bnt;
            // 
            // button8
            // 
            button8.BackColor = Color.White;
            button8.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button8.ForeColor = SystemColors.ActiveCaptionText;
            button8.Location = new Point(96, 326);
            button8.Name = "button8";
            button8.Size = new Size(58, 60);
            button8.TabIndex = 8;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = false;
            button8.Click += bnt;
            // 
            // button9
            // 
            button9.BackColor = Color.White;
            button9.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button9.ForeColor = SystemColors.ActiveCaptionText;
            button9.Location = new Point(27, 326);
            button9.Name = "button9";
            button9.Size = new Size(58, 60);
            button9.TabIndex = 9;
            button9.Text = "7";
            button9.UseVisualStyleBackColor = false;
            button9.Click += bnt;
            // 
            // button10
            // 
            button10.BackColor = Color.White;
            button10.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button10.ForeColor = SystemColors.ActiveCaptionText;
            button10.Location = new Point(27, 390);
            button10.Name = "button10";
            button10.Size = new Size(58, 60);
            button10.TabIndex = 10;
            button10.Text = "0";
            button10.UseVisualStyleBackColor = false;
            button10.Click += bnt;
            // 
            // button11
            // 
            button11.BackColor = Color.White;
            button11.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button11.ForeColor = SystemColors.ActiveCaptionText;
            button11.Location = new Point(96, 390);
            button11.Name = "button11";
            button11.Size = new Size(58, 60);
            button11.TabIndex = 11;
            button11.Text = ".";
            button11.UseVisualStyleBackColor = false;
            button11.Click += bnt;
            // 
            // button12
            // 
            button12.BackColor = Color.Black;
            button12.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button12.ForeColor = Color.White;
            button12.Location = new Point(241, 394);
            button12.Name = "button12";
            button12.Size = new Size(58, 60);
            button12.TabIndex = 12;
            button12.Text = "/";
            button12.UseVisualStyleBackColor = false;
            button12.Click += bnt;
            // 
            // button14
            // 
            button14.BackColor = Color.Black;
            button14.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button14.ForeColor = Color.White;
            button14.Location = new Point(241, 198);
            button14.Name = "button14";
            button14.Size = new Size(58, 60);
            button14.TabIndex = 14;
            button14.Text = "+";
            button14.UseVisualStyleBackColor = false;
            button14.Click += bnt;
            // 
            // button15
            // 
            button15.BackColor = Color.Black;
            button15.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button15.ForeColor = Color.White;
            button15.Location = new Point(165, 390);
            button15.Name = "button15";
            button15.Size = new Size(58, 60);
            button15.TabIndex = 15;
            button15.Text = "=";
            button15.UseVisualStyleBackColor = false;
            button15.Click += button15_Click;
            // 
            // button16
            // 
            button16.BackColor = Color.Black;
            button16.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button16.ForeColor = Color.White;
            button16.Location = new Point(241, 262);
            button16.Name = "button16";
            button16.Size = new Size(58, 60);
            button16.TabIndex = 15;
            button16.Text = "-";
            button16.UseVisualStyleBackColor = false;
            button16.Click += bnt;
            // 
            // button17
            // 
            button17.BackColor = Color.Black;
            button17.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button17.ForeColor = Color.White;
            button17.Location = new Point(241, 326);
            button17.Name = "button17";
            button17.Size = new Size(58, 60);
            button17.TabIndex = 16;
            button17.Text = "*";
            button17.UseVisualStyleBackColor = false;
            button17.Click += bnt;
            // 
            // button18
            // 
            button18.BackColor = Color.Maroon;
            button18.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button18.ForeColor = Color.White;
            button18.Location = new Point(241, 139);
            button18.Name = "button18";
            button18.Size = new Size(58, 55);
            button18.TabIndex = 17;
            button18.Text = "Clear";
            button18.UseVisualStyleBackColor = false;
            button18.Click += button18_Click;
            // 
            // button13
            // 
            button13.BackColor = Color.Maroon;
            button13.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button13.ForeColor = Color.White;
            button13.Location = new Point(279, 2);
            button13.Name = "button13";
            button13.Size = new Size(42, 36);
            button13.TabIndex = 18;
            button13.Text = "x";
            button13.UseVisualStyleBackColor = false;
            button13.Click += button13_Click;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.White;
            textBox2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(3, 2);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(96, 27);
            textBox2.TabIndex = 19;
            textBox2.Text = "  Calculator.";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(325, 465);
            Controls.Add(textBox2);
            Controls.Add(button13);
            Controls.Add(button18);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button13;
        private TextBox textBox2;
    }
}
